const express = require('express');
const router = express.Router();

const {RenderMain,RenderLogin,RenderRoom,Create_Room,join} = require('../controllers/main');

router.get('/',RenderMain );
router.get('/login',RenderLogin);

router.get('/rooms/:project_type',RenderRoom);
router.post('/rooms/:user_id/:room_id',join);

router.post('/New_Room',Create_Room);









module.exports = router;