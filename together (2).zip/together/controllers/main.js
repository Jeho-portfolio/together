const {Room,User} = require('../models');

exports.RenderMain = (req,res) => {
    if (req.user) {
        console.log(req.user.id);
        res.render('index',{
            User : req.user
        });    
    }
    else {
        res.render('index');
    }    
}

exports.RenderLogin = (req,res) => {
    res.render('login');
}

exports.RenderRoom = async (req,res,next) => {
    try {
        const rooms = await Room.findAll({
            where : {project_type : req.params.project_type},
            include: [{
                model: User,
                attributes:['user_id','name','major'],
                as : "Users",
            }],
            order:[['createdAt', 'DESC']],
        });

        res.render('index', {
            Rooms: rooms,
        });
        
    } catch(error) {
        console.log(error);
    }
    
}

exports.Create_Room = async (req,res,next) => {
    try {
        const New_Room  = await Room.create({
            project_name: req.body.project_name,
                
            leader : req.body.leader,
               
            contents : req.body.Room_info,
               
            project_start : req.body.start_date,
               
            project_end : req.body.end_date,
               
            occupancy : req.body.occupancy,
            
            project_type : req.body.end_date,
                
            kakao_chat : req.body.chat,
                
        });

        const data = {
            message: "방만들기 성공",
            success: true
        };

        res.status(200).send(data);
        res.redirect('/');
  
    } catch(error) {
        const data = {
            message: "방만들기 실패",
            success: false
        };
        console.log(error);
        res.status(500).send(data);
    }
}

exports.join = async(req,res,next)=> {
    try {
        const room = await Room.findOne({where : {id: req.params.room_id}});
        if (room) {
            await room.addUsers(req.params.user_id);
            res.send('success');
        }
        else {
            res.status(404).send('no user');
        }
    } catch(error) {
        console.error(error);
        next(error);
    }
};