const axios = require('axios');
const passport = require('passport');
const User = require('../models/User');
const Room = require('../models/Room');

exports.Auth_sejong = async (req, res) => {
    try {
        
        const requestBody = {
            id: req.body.id,  
            pw: req.body.pw   
        };

        const response = await axios.post('https://auth.imsejong.com/auth?method=DosejongSession', requestBody);
        console.log(response.data.result.body.name);
        const user = await User.findOne({where : {user_id : requestBody.id}});

        if (response.data.result.is_auth) {
            
            if (!user) {
                const New_memeber = await User.create({
                    user_id : requestBody.id,
                    name: response.data.result.body.name,  
                    major: response.data.result.body.major,   
                });
            }
          
            req.login(requestBody, (err) => {
              if (err) {
                  console.error(err);
                  return res.status(500).send('로그인 도중 에러 발생');
              }
              return res.redirect('/');
            });


      } else {
          return res.send({ message: "비밀번호를 다시 입력해주세요" });
      }

  } catch (error) {
      console.error(error);
      return res.status(500).send('서버 에러 발생');
  }
        
    
};
